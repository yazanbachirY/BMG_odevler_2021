kisiler = ["ahmed" , "omer" , "mustafa" , "osman"]
kulancilist = []

#2 liste ekrana yazdir
print(kisiler)

for i range(3)
#3 kulancidan 3 isim iste
kulancilist = input("enter the first name")

#4 kulanci girdiği isim listeye ekleyiniz ve ekrana yazdir
kisiler.append(kulancilist) 
print(kisiler)

#5 liste uzunluğu
print(len(kisiler))

#6 listenin 2. elemanını ekrana yazdırınız
print(kisiler[2])

#7 son elemanını sil
kisilr.pop(-1)